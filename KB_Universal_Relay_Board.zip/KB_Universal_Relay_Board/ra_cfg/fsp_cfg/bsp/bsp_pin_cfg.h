/* generated configuration header file - do not edit */
#ifndef BSP_PIN_CFG_H_
#define BSP_PIN_CFG_H_
#include "r_ioport.h"

/* Common macro for FSP header files. There is also a corresponding FSP_FOOTER macro at the end of this file. */
FSP_HEADER

#define ARDUINO_A3 (BSP_IO_PORT_00_PIN_03)
#define USER_SW1 (BSP_IO_PORT_00_PIN_04)
#define ARDUINO_A4 (BSP_IO_PORT_00_PIN_12)
#define ARDUINO_A5 (BSP_IO_PORT_00_PIN_14)
#define USER_SW2 (BSP_IO_PORT_00_PIN_15)
#define PMOD2_MISO (BSP_IO_PORT_02_PIN_02)
#define PMOD2_MOSI (BSP_IO_PORT_02_PIN_03)
#define PMOD2_CLK (BSP_IO_PORT_02_PIN_04)
#define PMOD2_SS (BSP_IO_PORT_02_PIN_05)
#define ARDUINO_D3_MIKROBUS_PWM (BSP_IO_PORT_04_PIN_00)
#define ARDUINO_SDA_MIKROBUS_SDA (BSP_IO_PORT_04_PIN_07)
#define ARDUINO_RX_MIKROBUS_RX (BSP_IO_PORT_04_PIN_10)
#define GROVE2_SDA (BSP_IO_PORT_05_PIN_01)
#define GROVE2_SCL (BSP_IO_PORT_05_PIN_02)
#define USER_LED1 (BSP_IO_PORT_05_PIN_03)
#define USER_LED2 (BSP_IO_PORT_05_PIN_04)
#define USER_LED3 (BSP_IO_PORT_05_PIN_05)
extern const ioport_cfg_t g_bsp_pin_cfg; /* RA2L1 EK */

void BSP_PinConfigSecurityInit();

/* Common macro for FSP header files. There is also a corresponding FSP_HEADER macro at the top of this file. */
FSP_FOOTER

#endif /* BSP_PIN_CFG_H_ */
