/*---------------------------------------------------------------------------
  Copyright 2006 Food Automation - Service Techniques (FAST.).  The
  computer program contained herein is the property of (FAST.) and may
  not be copied in whole or in part without prior written authorization
  from (FAST.).
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
File:   ModbusApplication.H
Date:   03/08/2013
Author: GLU

Description: This file contains the defines and structures for the Application.

REVISION HISTORY:
-------------------------------------------------------------------------*/
#ifndef __MODBUS_APPLICATION_H__
#define __MODBUS_APPLICATION_H__

#include "Modbus.h"
//*****************************************************************************
#define MODBUS_APP_SLAVE_ADDRESS                                     1
//*****************************************************************************
#define MODBUS_APP_AFCB_MODE_OFF                                     0
#define MODBUS_APP_AFCB_MODE_MELTING                                 1
#define MODBUS_APP_AFCB_MODE_BOILING                                 2
#define MODBUS_APP_AFCB_MODE_HEATING                                 3
#define MODBUS_APP_AFCB_MODE_READY                                   4
#define MODBUS_APP_AFCB_MODE_COOKING                                 5

//*****************************************************************************
#define MODBUS_APP_APPLIANCE_TYPE_GAS                                3
#define MODBUS_APP_APPLIANCE_TYPE_ELECTRIIC                          4

//*****************************************************************************
//old Version
#define MODBUS_APP_AFCB_STATUS_FILTERING                             0
#define MODBUS_APP_AFCB_STATUS_TOP_OFF                               1
#define MODBUS_APP_AFCB_STATUS_DRAINING                              2
#define MODBUS_APP_AFCB_STATUS_IDLE                                  3

//*****************************************************************************
#define MODBUS_APP_AFCB_MSG_SLAVE_BLOCKED_DRAIN          0x2001
                                                       
#define MODBUS_APP_AFCB_MSG_MASTER_BLOCKED_DRAIN_RETRY   0x2001
#define MODBUS_APP_AFCB_MSG_MASTER_BLOCKED_DRAIN_STOP    0x2002

//*****************************************************************************
typedef struct{
    union{
      MODBUS_UNSIGNED_8BIT modbusDiscretes[2][MODBUS_BOOLEANS];
      struct {         
         struct {
            U_BYTE autoTopOffStatusLeft;     // 0
            U_BYTE filterSoonLedStatusLeft;  // 1
            U_BYTE autoFilterCompLeft;       // 2
            U_BYTE drainSwitchStatusLeft;    // 3
            U_BYTE heatFeedbackStatusLeft;   // 4
            U_BYTE manualTopOffEventLeft;    // 5
            U_BYTE filterOffLineStatusLeft;  //  6
            U_BYTE BackupMode;               // 7
            U_BYTE unusedLeft_1[3];          // 8-10
            U_BYTE flushHoseInUsed;          // 11
            U_BYTE lowJibStatusOrRelayBoardStatus_3;       // 12  // was lowJibStatus
            U_BYTE relayBoardStatus[2];      // 13-14  combi to 2 bits
            U_BYTE unused_15;                // 15
            U_BYTE autoTopOffStatusRight;    // 16
            U_BYTE filterSoonLedStatusRight; // 17
            U_BYTE autoFilterCompRight;      // 18
            U_BYTE drainSwitchStatusRight;   // 19
            U_BYTE heatFeedbackStatusRight;  // 20
            U_BYTE manualTopOffEvebtRight;   // 21
            U_BYTE filterOffLineStatusRight; // 22
            U_BYTE unused_22_31[9];         // 23-31
         } tx;

         struct {
            U_BYTE sideOnStatusLeft;        // 0
            U_BYTE unused_1;                // 1
            U_BYTE leftBasketLeft;          // 2
            U_BYTE rightBasketLeft;         // 3
            U_BYTE unused_4;                // 4
            U_BYTE topOffReqLeft;           // 5
            U_BYTE filterReqLeft;           // 6
            U_BYTE drainReqLeft;            // 7
            U_BYTE autoFilterReqLeft;       // 8
            U_BYTE unused_9;                // 9
            U_BYTE autoTopOffEnableLeft;    // 10
            U_BYTE heatLeft;                // 11
            U_BYTE autoDisposeReqLeft;      // 12
            U_BYTE cleanReq;                // 13
            U_BYTE selfCleanBurnEnable;     // 14
            U_BYTE fryByWireEanble;         // 15
            U_BYTE sideOnStatusRight;       // 16
            U_BYTE unused_17;               // 17
            U_BYTE leftBasketRight;         // 18
            U_BYTE rightBasketRight;        // 19
            U_BYTE unused_20;               // 20
            U_BYTE topOffReqRight;          // 21
            U_BYTE filterReqRight;          // 22
            U_BYTE drainReqRight;           // 23
            U_BYTE autoFilterReqRight;      // 24
            U_BYTE unused_25;               // 25
            U_BYTE autoTopOffEnableRight;   // 26
            U_BYTE heatRight;               // 27
            U_BYTE autoDisposeReqRight;     // 28
            U_BYTE unused_29;               // 29
            U_BYTE aasEnable;               // 30
            U_BYTE disposeReq;              // 31
         } rx;
      } data;
   } io;
   
   union {
      MODBUS_UNSIGNED_16BIT modbusRegisters[2][MODBUS_REGISTERS];

      struct {  
         //note: the modbus take 2 bytes at time and using as big ending
         //       thus we have to reverse the byte defined order to make and
         //       Transmit/receive data in right order to/from modbus module
         struct {
            U_WORD oilLevelPrbReadingLeft;       // 0-1
            U_BYTE unUsed_3;                     // 2
            U_BYTE oilLevelDetectionStateLeft;   // 3
            U_WORD unUsedLeft_4_5;               // 4-5
            U_BYTE unUsedLeft;                   // 6
            U_BYTE acswStatus;                   // 7
            U_WORD oilLevelPrbReadingRight;      // 8-9
            U_BYTE unUsed_11;                    // 10
            U_BYTE oilLevelDetectionStateRight;  // 11
            U_WORD unUsedRight_12_13;            // 12-13
            U_WORD msgSlave;                     // 14-15
         } tx;

         struct {
            U_BYTE fillTimeLeft;                 //  0
            U_BYTE drainTimeLeft;                //  1    
            U_WORD filterTimeLeft;               //  2-3     
            U_BYTE unUsed4;                      //  4
            U_BYTE fryerModeLeft;                //  5    
            U_BYTE heatProfile;                  //  6
            U_BYTE autoTopOffTime;               //  7     
            U_BYTE fillTimeRight;                //  8
            U_BYTE drainTimeRight;               //  9     
            U_WORD filterTimeRight;              // 10-11      
            U_BYTE resourceCfg;                  // 12
            U_BYTE fryerModeRight;               // 13
            U_WORD msgMaster;                    // 14-15
         } rx;
      } data;
   } reg; 
   
}MODBUS_DATA_BUFFER;
#endif
