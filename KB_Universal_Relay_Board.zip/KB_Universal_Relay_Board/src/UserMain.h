/*
 * UserMain.h
 *
 *  Created on: Sep 22, 2022
 *      Author: spotdar
 */


#include "hal_data.h"

/******************************************************************************************/
/*                                 C O N S T A N T S                                      */
/******************************************************************************************/
typedef signed char S_BYTE;
typedef unsigned char U_BYTE;
typedef signed short S_WORD;
typedef unsigned short U_WORD;
typedef signed int S_INT;
typedef unsigned int U_INT;
typedef signed long S_DWORD;
typedef unsigned long U_DWORD;
typedef signed long S_LONG;
typedef unsigned long U_LONG;

//*********** Timer defines **************

#define  HUNDRED_MS_10MS_TIME_VALUE         10
#define ONE_SECOND_10MS_TIME_VALUE          100
#define TWO_SECONDS_10MS_TIME_VALUE         200
#define FIVE_SECONDS_10MS_TIME_VALUE        500
#define EIGHT_SECONDS_10MS_TIME_VALUE       800

//********** Debounce defines ************

#define  DEBOUNCE_TIMES_HUNDRED_MSEC        1   // 1 = 200mSEC debounce
                                                // 2 = 300mSEC debounce
                                                // 3 = 400mSEC debounce

//********* clean cycle states ***********

#define  INITIAL_BURN                     1     // clean cycle initial burn state
#define  PURGE                            2     // clean cycle purge state
#define  HEAT_ON                          3     // clean cycle heat on state
#define  HEAT_AND_CLEAN_ON                4     // clean cycle heat and clean on state
#define  DWELL                            5    // clean cycle dwell state

//****** UL test mode states ******

#define CYCLE_ALL_RELAYS                  2
#define ALL_RELAYS_ON_STEADY              3
#define ALL_RELAYS_OFF_STEADY             4

//********* Miscleneous defines************
#define  FALSE                   0
#define  TRUE                    1
#define  YES                     1
#define  NO                      0
#define  READ                    0
#define  WRITE                   1
#define  INACTIVE                0
#define  ACTIVE                  1
#define  ON                      1
#define  OFF                     0
#define  SET                     1
#define  CLEAR                   0
#define  HIGH                    1
#define  LOW                     0

//******* INPUT I/O DEFINITIONS ***********
#define HDE_SENSE                         R_BSP_PinRead(BSP_IO_PORT_00_PIN_02)
#define HEAT_DEMAND_FEEDBACK              R_BSP_PinRead(BSP_IO_PORT_00_PIN_01)
#define DRAIN_FLOAT_SENSE                 R_BSP_PinRead(BSP_IO_PORT_00_PIN_00)
#define BACKUP_SIDE_ON_SENSE              R_BSP_PinRead(BSP_IO_PORT_07_PIN_08)
#define AC_PRESENT_SENSE                  R_BSP_PinRead(BSP_IO_PORT_04_PIN_11)
#define BACKUP_HEAT_DEMAND_SENSE          R_BSP_PinRead(BSP_IO_PORT_04_PIN_15)

#define MODBUS_SW3                        R_BSP_PinRead(BSP_IO_PORT_03_PIN_04)
#define MODBUS_SW2                        R_BSP_PinRead(BSP_IO_PORT_08_PIN_08)
#define MODBUS_SW1                        R_BSP_PinRead(BSP_IO_PORT_08_PIN_09)

#define MODBUS_DIRECT_WIRE_SEL            R_BSP_PinRead(BSP_IO_PORT_04_PIN_08)

//******* OUTPUT I/O DEFINITIONS ***********
#define HEAT_DEMAND_RELAY(Pin_State)                 Pin_State?R_BSP_PinWrite(BSP_IO_PORT_01_PIN_02, BSP_IO_LEVEL_HIGH):R_BSP_PinWrite(BSP_IO_PORT_01_PIN_02, BSP_IO_LEVEL_LOW)
#define SIDE_ON_RELAY(Pin_State)                     Pin_State?R_BSP_PinWrite(BSP_IO_PORT_01_PIN_03, BSP_IO_LEVEL_HIGH):R_BSP_PinWrite(BSP_IO_PORT_01_PIN_02, BSP_IO_LEVEL_LOW)
#define CLEAN_RELAY(Pin_State)                       Pin_State?R_BSP_PinWrite(BSP_IO_PORT_01_PIN_04, BSP_IO_LEVEL_HIGH):R_BSP_PinWrite(BSP_IO_PORT_01_PIN_02, BSP_IO_LEVEL_LOW)
#define BASKET_LIFT_RIGHT(Pin_State)                 Pin_State?R_BSP_PinWrite(BSP_IO_PORT_01_PIN_05, BSP_IO_LEVEL_HIGH):R_BSP_PinWrite(BSP_IO_PORT_01_PIN_02, BSP_IO_LEVEL_LOW)
#define BASKET_LIFT_LEFT(Pin_State)                  Pin_State?R_BSP_PinWrite(BSP_IO_PORT_01_PIN_06, BSP_IO_LEVEL_HIGH):R_BSP_PinWrite(BSP_IO_PORT_01_PIN_02, BSP_IO_LEVEL_LOW)

#define DIAGNOSTIC_LED(Pin_State)                    Pin_State?R_BSP_PinWrite(BSP_IO_PORT_01_PIN_09, BSP_IO_LEVEL_HIGH):R_BSP_PinWrite(BSP_IO_PORT_01_PIN_02, BSP_IO_LEVEL_LOW)
#define RS485_INT_PIN(Pin_State)                     Pin_State?R_BSP_PinWrite(BSP_IO_PORT_03_PIN_03, BSP_IO_LEVEL_HIGH):R_BSP_PinWrite(BSP_IO_PORT_01_PIN_02, BSP_IO_LEVEL_LOW)

/******************************************************************************************/
/*                           C L E A N  C Y C L E  F L A G S                              */
/******************************************************************************************/

typedef struct{
    U_BYTE cleanFinished;       // flag for indicating if clean cycle has been successfully completed
    U_BYTE cleanActive;         // flag for indicating if clean cycle is currently active
    U_BYTE initialBurnActive;   // flag for indicating if initial burn step in clean cycle is active
    U_BYTE purgeDelayActive;    // flag for indicating if purge delay step in clean cycle is active
    U_BYTE heatOnActive;           // flag for indicating if heat on only step in clean cycle is active
    U_BYTE heatAndCleanActive;  // flag for indicating if heat and clean step in clean cycle is active
    U_BYTE dwellActive;         // flag for indicating if dwell step in clean cycle is active
   U_BYTE heatDemandReceived; // flag for getting first heat demand after side on turned on
} CLEAN_CYCLE_FLAGS;         // cleanCycleFlags

/******************************************************************************************/
/*                                M I S C  F L A G S                                      */
/******************************************************************************************/

typedef struct{
    U_BYTE  ledOnOff;           // flag byte to track diagnostic LED on/off status
   U_BYTE   testMode;         // flag byte to inidicate test mode
   U_BYTE   timeToDoHundredMsTasks;
                              // for processing when it's time to do 100mSEC tasks
   U_BYTE   timeToDoOneSecTasks;
                              // for processing when it's time to do 1 second tasks
   // test code
   U_BYTE   ledToggle;
   // end test code
}   MISC_FLAGS;                // miscFlags

/******************************************************************************************/
/*             R E L A Y  A N D  R E L A Y  C T L  S I G N A L  F L A G S                 */
/******************************************************************************************/

typedef struct{
   U_BYTE   sideOnRelay;      // side on relay control flag
   U_BYTE   heatDemandRelay;  // heat demand relay control flag
   U_BYTE   cleanRelay;       // clean relay control flag
   U_BYTE   basketLiftRightRelaySignal;
                              // basket lift right signal control flag
   U_BYTE   basketLiftLeftRelaySignal;
                              // basket lift left signal control flag
}  RELAY_CONTROL_FLAGS;       // relayControlFlags


/******************************************************************************************/
/*                H O S T  S E R I A L  I / O  S T A T U S  F L A G S                     */
/******************************************************************************************/

typedef struct{
    U_BYTE sideOn;             // command byte from host for side on
    U_BYTE heatDemand;          // command byte from host for heat demand
   U_BYTE basketLiftRight;    // command byte from host for basket lift right
   U_BYTE basketLiftLeft;     // command byte from host for basket lift left
    U_BYTE pilotActive;         // command byte to host from us for indicating
                              // pilot status
}   COMM_STATUS;               // commStatusFlags

/******************************************************************************************/
/*                    D I R E C T  I N P U T  S T A T U S  F L A G S                      */
/******************************************************************************************/

// status of direct inputs to us

typedef struct{
    U_BYTE hdeSense;              // Heat Demand Enable sense
    U_BYTE heatFeedbackSense;      // Heat Feedback Sense (i.e. pilot standing status)
    U_BYTE drainFloatSense;        // Drain Float Sense
   U_BYTE backupSideOnSense;     // Back-up control side on input to us.
   U_BYTE acPresentSense;        // touch screen control (have ac) or back-up control
                                 // (no ac)
   U_BYTE backupHeatDemandSense; // Back-up control heat demand input to us.
}   INPUT_STATUS;                 // inputStatus
/******************************************************************************************/
/*                        F U N C T I O N  P R O T O T Y P E S                            */
/******************************************************************************************/
void user_uart0_callback(uart_callback_args_t *p_args);
void user_uart0_Print_msg(char *p_msg);
void Init_hardware(void);
void Init_system(void);
void OneSecondTasks(void);
void GetModbusAddress(void);
void AllRelayOutputsOff(void);
void UpdateHostCommFlags(void);
void RunSystem(void);
void InitCleanStateMachine(void);
void cleanCycle(void);
void Relays(void);
void Leds(void);
void Usermain(void);
/*********************************************************************************************/




