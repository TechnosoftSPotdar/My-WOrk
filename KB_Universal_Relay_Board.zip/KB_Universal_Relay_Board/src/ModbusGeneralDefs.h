/****************************************************************************
Copyright 2013 Food Automation - Service Techniques (FAST.).  The
computer program contained herein is the property of (FAST.) and may
not be copied in whole or in part without prior written authorization
from (FAST.).

Filename:         ModbusGeneralDefs.h     
Creation Date:    March 13, 2013 
Author:           A. Zimmerman

Description:      This file contains the #defines for MODBUS types

REVISION HISTORY:
	Initial 3/13/13
*****************************************************************************/ 
#ifndef _MODBUS_GENERAL_DEFS_H_
#define _MODBUS_GENERAL_DEFS_H_

#define MODBUS_SIGNED_8BIT		   char
#define MODBUS_UNSIGNED_8BIT	   unsigned char
#define MODBUS_SIGNED_16BIT		int
#define MODBUS_UNSIGNED_16BIT	   unsigned int
#define MODBUS_SIGNED_32BIT		long
#define MODBUS_UNSIGNED_32BIT	   unsigned long

typedef signed char S_BYTE;
typedef unsigned char U_BYTE;
typedef signed short S_WORD;
typedef unsigned short U_WORD;
typedef signed int S_INT;
typedef unsigned int U_INT;
typedef signed long S_DWORD;
typedef unsigned long U_DWORD;
typedef signed long S_LONG;
typedef unsigned long U_LONG;

#define MODBUS_FALSE			      0
#define MODBUS_TRUE			      1

#define MODBUS_NULL              0

#endif //_MODBUS_GENERAL_DEFS_H_
