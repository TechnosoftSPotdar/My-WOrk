/****************************************************************************
Copyright 2013 Food Automation - Service Techniques (FAST.).  The
computer program contained herein is the property of (FAST.) and may
not be copied in whole or in part without prior written authorization
from (FAST.).

Filename:         Modbus.h     
Creation Date:    March 13, 2013 
Author:           A. Zimmerman

Description:      This file contains the #defines for PITCO Modus usage

REVISION HISTORY:
	Initial 3/13/13
*****************************************************************************/ 
#ifndef _MODBUS_DEF_H_
#define _MODBUS_DEF_H_
#include "ModbusGeneralDefs.h"

#define MODBUS_START_DELIMITER						      0x3A	//':'
#define MODBUS_ASCII_CHAR_CR					         	0x0D	//CR
#define MODBUS_ASCII_CHAR_LF					         	0x0A	//LF
#define MODBUS_ASCII_CHAR_ZERO				         	0x30	//'0'
#define MODBUS_ASCII_CHAR_NINE				         	0x39	//'9'
#define MODBUS_ASCII_CHAR_A							      0x41	//'A'
#define MODBUS_ASCII_CHAR_F							      0X46	//'F'

#define MODBUS_SLAVES								         1			//1 Slaves  allowed
#define MODBUS_BOOLEANS								         32			//32 Booleans
#define MODBUS_REGISTERS							         8			//8 UNSIGNED WORDS
#define MODBUS_MIN_SLAVE_ADDRESS					         2
#define MODBUS_MAX_SLAVE_ADDRES						      9

//MODBUS COMMANDS
#define MODBUS_READ_COILS							         1
#define MODBUS_READ_DISCRETES						         2     //currently implemented
#define MODBUS_READ_HOLDING_REGISTERS				      3     
#define MODBUS_READ_INPUT_REGISTER					      4     //currently implemented
#define MODBUS_WRITE_COILS							         15    //currently implemented
#define MODBUS_WRITE_MULTIPLE_REGISTERS				   16    //currently implemented 


//Modbus Constant String Defines for Modbus Response Headers
#define MODBUS_DIRRR									         modbusDiscreteInputsReadResponse			//MODBUS_READ_DISCRETES			
#define MODBUS_DOWRR									         modbusDiscreteOutputsWriteResponse	//MODBUS_WRITE_COILS				
#define MODBUS_RIRRR									         modbusRegisterInputsReadResponse		//MODBUS_READ_INPUT_REGISTER		
#define MODBUS_ROWRR									         modbusRegisterOutputsWriteResponse	//MODBUS_WRITE_MULTIPLE_REGISTERS	

#define MODBUS_SLAVE_MIN_ADDR						         1
#define MODBUS_SLAVE_MAX_ADDR						         MODBUS_SLAVES

#define MODBUS_TRANSMIT_DATA						         0
#define MODBUS_RECEIVE_DATA						       	1

#define MODBUS_ACTIVITY_TIMEOUT_IN_100MSECS			   50

#define MODBUS_BAD_LRC								         30
#define MODBUS_NONCOMPATIBLE						         31
#define MODBUS_SLAVE_MISMATCH						         32
#define MODBUS_RECEIVE_SUCCESS					         40

#define MODBUS_DISCRETE_READ						         0
#define MODBUS_REGISTER_READ						         2
#define MODBUS_DISCRETE_OUTPUT_READ_SUCCESS			   (MODBUS_RECEIVE_SUCCESS + MODBUS_DISCRETE_READ + 0)
#define MODBUS_DISCRETE_INPUT_READ_SUCCESS			   (MODBUS_RECEIVE_SUCCESS + MODBUS_DISCRETE_READ + 1)
#define MODBUS_REGISTER_OUTPUT_READ_SUCCESS			   (MODBUS_RECEIVE_SUCCESS + MODBUS_REGISTER_READ + 0)
#define MODBUS_REGISTER_INPUT_READ_SUCCESS			   (MODBUS_RECEIVE_SUCCESS + MODBUS_REGISTER_READ + 1)
#define MODBUS_DISCRETE_WRITE						         4
#define MODBUS_REGISTER_WRITE						         5
#define MODBUS_DISCRETE_OUTPUT_WRITE_SUCCESS		      (MODBUS_RECEIVE_SUCCESS + MODBUS_DISCRETE_WRITE + 1)
#define MODBUS_REGISTER_OUTPUT_WRITE_SUCCESS		      (MODBUS_RECEIVE_SUCCESS + MODBUS_REGISTER_WRITE + 1)

#define MODBUS_SLAVE_ADDR_LOCATION                    1
#define MODBUS_FUNCTION_LOCATION                      3
#define MODBUS_DISCRETE_COUNT_LOCATION                13
#define MODBUS_DISCRETE_BYTE_COUNT                    (MODBUS_BOOLEANS/8)
#define MODBUS_BOOLEAN_DATA_START_LOCATION            15
#define MODBUS_REGISTER_COUNT_LOCATION                13
#define MODBUS_REGISTER_DATA_START_LOCATION           15
#define MODBUS_REGISTER_BYTE_COUNT                    (MODBUS_REGISTERS*2)
#define MODBUS_READ_REQUEST_ADDR_HI_LOCATION          5
#define MODBUS_READ_REQUEST_ADDR_LO_LOCATION          7
#define MODBUS_READ_REQUEST_QTY_HI_LOCATION           9
#define MODBUS_READ_REQUEST_QTY_LO_LOCATION           11
#define MODBUS_WRITE_REQUEST_ADDR_HI_LOCATION         5
#define MODBUS_WRITE_REQUEST_ADDR_LO_LOCATION         7
#define MODBUS_WRITE_REQUEST_QTY_HI_LOCATION          9
#define MODBUS_WRITE_REQUEST_QTY_LO_LOCATION          11

//MODBUS RESPONSE FRAME LENGTHS INCLUDING :, LRC and CRLF
#define MODBUS_DISCRETE_READ_FRAME_LENGTH    17 //:(1) + slaveAddr(2) + func(2) + Add(4) + count(4) + LRC(2) + CRLF(2)
#define MODBUS_REGISTER_READ_FRAME_LENGTH    17 //:(1) + slaveAddr(2) + func(2) + Add(4) + count(4) + LRC(2) + CRLF(2)
#define MODBUS_WRITE_COILS_FRAME_LENGTH      27 //:(1) + slaveAddr(2) + func(2) + Add(4) + qty(4) + byteCount(2) + ((qty/8)*2) + LRC(2) + CRLF(2)
#define MODBUS_WRITE_REGISTERS_FRAME_LENGTH  51 //:(1) + slaveAddr(2) + func(2) + Add(4) + qty(4) + byteCount(2) + (2*Qty*2) + LRC(2) + CRLF(2)


//Comment out for BIG ENDIAN PROCESSOR
#define MODBUS_PROCESSOR_LITTLE_ENDIAN                1

//*****************************************************************************
//the 2 is for transmit/receive sides where 0 - is transmit and 1 is receive side
typedef struct{
	MODBUS_UNSIGNED_8BIT modbusDiscretes[2][MODBUS_BOOLEANS];
	MODBUS_UNSIGNED_16BIT modbusRegisters[2][MODBUS_REGISTERS];
} MODBUS_DATA;

//*****************************************************************************
void ModbusInit( MODBUS_DATA *data );
void ModbusReadRequestResponse(MODBUS_SIGNED_8BIT type, MODBUS_UNSIGNED_8BIT address);
void ModbusWriteRequestResponse(const MODBUS_SIGNED_8BIT * type, MODBUS_UNSIGNED_8BIT address);
void ModbusUpdateService( MODBUS_UNSIGNED_8BIT slave_Address );
MODBUS_UNSIGNED_8BIT ModbusDataValid(void);

#endif //_MODBUS_DEF_H_
