/*
 * UserMain.c
 *
 *  Created on: Sep 22, 2022
 *      Author: spotdar
 */
/**********************************************************************/
#include "UserMain.h"
#include "ModbusApplication.h"
#include "hal_data.h"
#include "Modbus.h"
#include "ModbusComm.h"
/**********************************************************************/
//Global Variables

volatile CLEAN_CYCLE_FLAGS        cleanCycleFlags;
volatile COMM_STATUS              commStatusFlags;
volatile INPUT_STATUS             inputStatus;
volatile MISC_FLAGS               miscFlags;
volatile RELAY_CONTROL_FLAGS      relayControlFlags;

volatile U_BYTE  hundredMilisecondTaskTimer;
volatile U_INT   dwellTimer;
volatile U_BYTE  currentState;
volatile U_BYTE  nextState;
volatile U_BYTE  hdeSenseCounter;
volatile U_BYTE  heatFeedbackSenseCounter;
volatile U_BYTE  drainFloatSenseCounter;
volatile U_BYTE  backupSideOnCounter;
volatile U_BYTE  acPresentCounter;
volatile U_BYTE  backupHeatDemandCounter;
volatile U_BYTE  oneSecondTaskTimer;
volatile U_BYTE  currentModbusAddress;
volatile U_BYTE  operationalCounter;

MODBUS_DATA_BUFFER modbusData;
/**********************************************************************/
void Init_hardware(void)
{
    R_BSP_PinAccessEnable();
    baud_setting_t baud_setting;
    uint32_t       baud_rate                 = 115200;
    bool           enable_bitrate_modulation = true;
    uint32_t       error_rate_x_1000         = 5000;
    R_SCI_UART_BaudCalculate(baud_rate, enable_bitrate_modulation, error_rate_x_1000, &baud_setting);
    R_SCI_UART_BaudSet(&g_uart0_ctrl, (void *) &baud_setting);
    R_SCI_UART_Open (&g_uart0_ctrl, &g_uart0_cfg);

}
/**********************************************************************/
void user_uart0_Print_msg(char *p_msg)
{
    char *p_temp_ptr = (char *)p_msg;
    uint8_t p_msg_len = ((uint8_t)(strlen(p_temp_ptr)));
    while(p_msg_len--){R_SCI_UART_Write (&g_uart0_ctrl,(uint8_t const *) p_msg++, 1); R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);}
}
/**********************************************************************/
void user_uart0_callback(uart_callback_args_t *p_args)
{
    if(UART_EVENT_RX_CHAR == p_args->event)
    {
        Modbus_UART1_Receive((MODBUS_UNSIGNED_8BIT) p_args->data);
    }
}
/**********************************************************************/
void Init_system(void)
{

   //tenMilisecondTimer = CLEAR;
   hundredMilisecondTaskTimer = HUNDRED_MS_10MS_TIME_VALUE;
   dwellTimer = CLEAR;
   currentState = INITIAL_BURN;
   nextState = currentState;

   commStatusFlags.sideOn = NO;
   commStatusFlags.heatDemand = NO;
   commStatusFlags.basketLiftRight = NO;
   commStatusFlags.basketLiftLeft = NO;
   commStatusFlags.pilotActive = NO;

   cleanCycleFlags.cleanFinished = NO;
   cleanCycleFlags.cleanActive = NO;
   cleanCycleFlags.initialBurnActive = NO;
   cleanCycleFlags.purgeDelayActive = NO;
   cleanCycleFlags.heatOnActive = NO;
   cleanCycleFlags.heatAndCleanActive = NO;
   cleanCycleFlags.dwellActive = NO;
   cleanCycleFlags.heatDemandReceived = FALSE;

   inputStatus.hdeSense = NO;
   inputStatus.heatFeedbackSense = NO;
   inputStatus.drainFloatSense = NO;

   relayControlFlags.sideOnRelay = OFF;
   relayControlFlags.heatDemandRelay = OFF;
   relayControlFlags.cleanRelay = OFF;
   relayControlFlags.basketLiftRightRelaySignal = OFF;
   relayControlFlags.basketLiftLeftRelaySignal = OFF;

   miscFlags.ledOnOff = OFF;
   miscFlags.testMode = NO;
   miscFlags.timeToDoHundredMsTasks = NO;

   hdeSenseCounter = DEBOUNCE_TIMES_HUNDRED_MSEC;
   heatFeedbackSenseCounter = DEBOUNCE_TIMES_HUNDRED_MSEC;
   drainFloatSenseCounter = DEBOUNCE_TIMES_HUNDRED_MSEC;

   AllRelayOutputsOff();

   // test code

   operationalCounter = CLEAR;

   // end test code

}
/**********************************************************************/
void AllRelayOutputsOff(void)
{
    // turn all relays off and make all relay drive signals inactive
    HEAT_DEMAND_RELAY(ON);
    SIDE_ON_RELAY(ON);
    CLEAN_RELAY(ON);
    BASKET_LIFT_RIGHT(ON);
    BASKET_LIFT_LEFT(ON);
    R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);
}
/**********************************************************************/
void GetModbusAddress(void)
{

   // Dip switch settings vs. resultant modbus address
   //
   // SW1   SW2   SW3     MODBUS ADDRESS SET
   // ---------------------------------------
   // OFF   OFF   OFF             2
   // ON    OFF   OFF             3
   // OFF   ON    OFF             4
   // ON    ON    OFF             5
   // OFF   OFF   ON              6
   // ON    OFF   ON              7
   // OFF   ON    ON              8
   // ON    ON    ON              9

    currentModbusAddress = 0x00;
    currentModbusAddress |= (U_BYTE) ((MODBUS_SW3 << 2) | (MODBUS_SW2 << 1) | (MODBUS_SW1));
    currentModbusAddress += 2;

}
/**********************************************************************/
void OneSecondTasks(void)
{
  if(YES == miscFlags.timeToDoOneSecTasks)       // if time to do 1 second tasks...
   {
      if(MODBUS_DIRECT_WIRE_SEL == HIGH)                            // if not in test mode...
      {

         if (TRUE == (ModbusDataValid()))
         {
            miscFlags.ledOnOff ^= 1;              // use as running indicator
         }

      }
      else{

         // in test mode...

         miscFlags.ledOnOff ^= 1;                 // use as running indicator
                                                  // unconditionally

         switch(currentModbusAddress)             // execute current test mode state
                                                  // based on SW1 dipswitch...
         {
            case CYCLE_ALL_RELAYS:                // cycle output relays?

               relayControlFlags.heatDemandRelay ^= 1;
               relayControlFlags.sideOnRelay ^= 1;
               relayControlFlags.cleanRelay ^= 1;
               relayControlFlags.basketLiftRightRelaySignal ^= 1;
               relayControlFlags.basketLiftLeftRelaySignal ^= 1;

               break;

            case ALL_RELAYS_ON_STEADY:            // output relays on steady?

               relayControlFlags.heatDemandRelay = ON;
               relayControlFlags.sideOnRelay = ON;
               relayControlFlags.cleanRelay = ON;
               relayControlFlags.basketLiftRightRelaySignal = ON;
               relayControlFlags.basketLiftLeftRelaySignal = ON;

               break;

            default:                              // any other SW1 dipswitch setting
                                                  // means relays off steady...

               relayControlFlags.heatDemandRelay = OFF;
               relayControlFlags.sideOnRelay = OFF;
               relayControlFlags.cleanRelay = OFF;
               relayControlFlags.basketLiftRightRelaySignal = OFF;
               relayControlFlags.basketLiftLeftRelaySignal = OFF;
         }

     }
      miscFlags.timeToDoOneSecTasks = NO;
   }
}
/**********************************************************************/
void Leds(void)
{
   if(ON == miscFlags.ledOnOff)       // control diagnostic LED as per
                                      // current state of LED status flag
   {
      DIAGNOSTIC_LED(ON);                      // turn on if it's supposed to be on
   }
   else
   {
      DIAGNOSTIC_LED(OFF);                     // turn off if it's supposed to be off
   }
}
/**********************************************************************/
void Relays(void)
{

   if(ON == relayControlFlags.heatDemandRelay) // does heat demand relay
                                               // need to be on?
   {
      HEAT_DEMAND_RELAY(ON);                                // yes, turn on heat demand relay

   }
    else
    {
        HEAT_DEMAND_RELAY(OFF);                              // no, turn off heat demand relay
    }

   if(ON == relayControlFlags.sideOnRelay)     // does side on relay
                                               // need to be on?
   {
      SIDE_ON_RELAY(ON);                                // yes, turn on side on relay

   }
    else
    {
        SIDE_ON_RELAY(OFF);                             // no, turn off side on relay
    }

   if(ON == relayControlFlags.cleanRelay)      // does clean relay need
                                               // to be on?
   {
      CLEAN_RELAY(ON);                             // yes, turn on clean relay

   }
    else
    {
        CLEAN_RELAY(OFF);                              // no, turn off clean relay
    }

   if(ON == relayControlFlags.basketLiftRightRelaySignal)
                                               // enable basket lift right?
   {
      BASKET_LIFT_RIGHT(ON);                             // yes, enable basket lift right

   }
    else
    {
        BASKET_LIFT_RIGHT(OFF);                              // no, disable basket lift right
    }

   if(ON == relayControlFlags.basketLiftLeftRelaySignal)
                                               // enable basket lift left?
   {
      BASKET_LIFT_LEFT(ON);                              // yes, enable basket lift left

   }
    else
    {
        BASKET_LIFT_LEFT(OFF);                               // no, disable basket lift left
    }
}
/**********************************************************************/
void RunSystem(void)
{

   if(YES == commStatusFlags.sideOn)          // if host is requesting side on...
   {
      relayControlFlags.sideOnRelay = ON;     // turn on side on relay

        if(NO == cleanCycleFlags.cleanFinished) // has a clean cycle been run since
                                               // Side On became active?
        {
         if(YES == commStatusFlags.heatDemand)
                                              // does host want heat demand relay on?
            {
            cleanCycleFlags.heatDemandReceived = TRUE;
         }
         if (TRUE == cleanCycleFlags.heatDemandReceived)
         {
               cleanCycle();                        // if not, must run an initial clean cycle
         }
        }
        else                                    // clean cycle has been run...
        {
            if(YES == inputStatus.hdeSense)
                                                 // do we have a standing pilot?
            {
               commStatusFlags.pilotActive = YES;
                                              // yes, save status in case host
                                                 // ever wants to know of it...
               if(YES == commStatusFlags.heatDemand)
                                              // does host want heat demand relay on?
               {

               relayControlFlags.heatDemandRelay = ON;
                                              // yes, turn on heat demand relay

            }
            else
            {

               relayControlFlags.heatDemandRelay = OFF;
                                              // no, turn off heat demand relay

            }

            }
            else
            {
            relayControlFlags.heatDemandRelay = OFF;
                                              // heat demand relay must be turned off
                                              // if we have no standing pilot...
                commStatusFlags.pilotActive = NO; // no, pilot flame is out can't do
                                              // anything, might want to report
                                              // this to host...
          }
       }
   }
   else
   {
      relayControlFlags.sideOnRelay = OFF;    // turn on side off relay
      InitCleanStateMachine();                // make sure clean cycle occurs on
   }

   //******************* basket lift relay control signals *********************

   if(YES == commStatusFlags.basketLiftRight) // active right basket control signal
                                              // from host?
   {
      relayControlFlags.basketLiftRightRelaySignal = ON;
                                              // yes, activate right basket ctl.
   }
   else
   {
      relayControlFlags.basketLiftRightRelaySignal = OFF;
                                              // no, deactivate right basket ctl.
   }

   if(YES == commStatusFlags.basketLiftLeft)  // active left basket control signal
                                              // from host?
   {
      relayControlFlags.basketLiftLeftRelaySignal = ON;
                                              // yes, activate left basket ctl.
   }
   else
   {
      relayControlFlags.basketLiftLeftRelaySignal = OFF;
                                              // no, deactivate left basket ctl.
   }

}
/**********************************************************************/
void InitCleanStateMachine(void)
{
   nextState = INITIAL_BURN;                    // reset critical flags and variables
                                                // that control clean cycle.
   currentState = nextState;
   cleanCycleFlags.cleanFinished = NO;
    cleanCycleFlags.cleanActive = NO;
    cleanCycleFlags.initialBurnActive = NO;
    cleanCycleFlags.purgeDelayActive = NO;
    cleanCycleFlags.heatOnActive = NO;
    cleanCycleFlags.heatAndCleanActive = NO;
    cleanCycleFlags.dwellActive = NO;
   cleanCycleFlags.heatDemandReceived = FALSE;
   dwellTimer = 0;

   // clean cycle has direct control over both heat demand relay and clean relay,
   // if the clean cycle is aborted, these relays must be turned off as a clean
   // cycle failsafe...

   relayControlFlags.heatDemandRelay = OFF;     // turn off heat demand relay
   relayControlFlags.cleanRelay = OFF;          // turn off clean relay
}
/**********************************************************************/
void UpdateHostCommFlags(void)
{
   #ifdef DBG
   static char resetComm = FALSE;
   #endif

   if (inputStatus.acPresentSense == ACTIVE){  // if primary AC power is present then
                                               // run normally from modbus host commands...

      if (FALSE == (ModbusDataValid()))
      {
         //INACTIVATE ALL OUTPUTS til the Modbus has activity from the MASTER
         commStatusFlags.sideOn = INACTIVE;
         commStatusFlags.heatDemand = INACTIVE;
         commStatusFlags.basketLiftRight = INACTIVE;
         commStatusFlags.basketLiftLeft = INACTIVE;

         #ifdef DBG
         if (resetComm == FALSE)  //reinitialize comm if there is communication error
         {
            resetComm = TRUE;
            ModbusInit((void *)&modbusData); //initialize modbus data
         }
         #endif
      }
      else
      {
         #ifdef DBG
         resetComm = FALSE;
         #endif
         //ACTIVATE ALL OUTPUTS from MASTER received on Modbus
         commStatusFlags.sideOn = modbusData.io.data.rx.sideOnStatusLeft;
         commStatusFlags.heatDemand = modbusData.io.data.rx.heatLeft ;
         commStatusFlags.basketLiftRight = modbusData.io.data.rx.rightBasketLeft ;
         commStatusFlags.basketLiftLeft =  modbusData.io.data.rx.leftBasketLeft ;
      }
   }

   // primary AC power is not present, run from backup control...

   else{

      // process side-on input from backup control...

      if(inputStatus.backupSideOnSense == ACTIVE)
                                             // if backup control side-on
                                             // signal is active
      {
         commStatusFlags.sideOn = SET;       // side-on is active
      }
      else
      {
         commStatusFlags.sideOn = CLEAR;     // side-on is inactive
      }

      // process heat-demand input from backup control...

      if(inputStatus.backupHeatDemandSense)  // if backup control heat
                                             // demand signal is active
      {
         commStatusFlags.heatDemand = SET;   // heat demand is active
      }
      else
      {
         commStatusFlags.heatDemand = CLEAR; // heat demand is inactive
      }
   }

   //unconditionally maintain the input status bits to have modbus send out
   //(even if modbus is broken...)

   modbusData.io.data.tx.heatFeedbackStatusLeft = inputStatus.heatFeedbackSense;
   modbusData.io.data.tx.drainSwitchStatusLeft = inputStatus.drainFloatSense;
   modbusData.io.data.tx.BackupMode = ~(inputStatus.acPresentSense);
}
/**********************************************************************/
void cleanCycle(void)
{

   currentState = nextState;  // load state machine with next state based on last pass
                              // through state machine

   /****************************************************************/
   /* State machine execution begins here...                       */
   /****************************************************************/

   switch(currentState)                                  // execute current state
   {
      case INITIAL_BURN:                                 // if state is initial burn (default
                                                         // initial state)...
         if(NO == cleanCycleFlags.initialBurnActive)     // first pass through initial burn?
         {
            dwellTimer = TWO_SECONDS_10MS_TIME_VALUE;    // init initial burn time delay
            cleanCycleFlags.initialBurnActive = YES;     // track that we're in initial burn state
            cleanCycleFlags.cleanActive = YES;           // clean cycle is active

         }
         if(YES == inputStatus.hdeSense)                 // is standing pilot present?
         {
            relayControlFlags.heatDemandRelay = ON;      // yes, turn on heat demand relay.
            if(0 == dwellTimer)                          // initial burn dwell time delay over?
            {
               cleanCycleFlags.initialBurnActive = NO;   // yes, done with initial burn
               nextState = PURGE;                        // onto purge part of process...
            }
         }
         else
         {
            InitCleanStateMachine();                     // no... can't execute clean cycle...
         }
         break;

      case PURGE:                                        // if state is purge...

         if(NO == cleanCycleFlags.purgeDelayActive)      // first pass through purge?
         {
            dwellTimer = FIVE_SECONDS_10MS_TIME_VALUE;   // init initial purge time delay
            cleanCycleFlags.purgeDelayActive = YES;      // track that we're in purge state
         }
         if(YES == inputStatus.hdeSense)                 // is standing pilot present?
         {
            relayControlFlags.heatDemandRelay = OFF;     // yes, turn off heat demand relay.
            if(0 == dwellTimer)                          // purge dwell time delay over?
            {
               cleanCycleFlags.purgeDelayActive = NO;    // yes, done with purge
               nextState = HEAT_ON;                      // onto heat on part of process...
            }
         }
         else
         {
            InitCleanStateMachine();                     // no... can't execute clean cycle...
         }
         break;

      case HEAT_ON:                                      // if state is heat on...

         if(NO == cleanCycleFlags.heatOnActive)          // first pass through heat on?
         {
            dwellTimer = ONE_SECOND_10MS_TIME_VALUE;     // init initial heat on time delay
            cleanCycleFlags.heatOnActive = YES;          // track that we're in heat on state
         }
         if(YES == inputStatus.hdeSense)                  // is standing pilot present?
         {
            relayControlFlags.heatDemandRelay = ON;      // yes, turn on heat demand relay.
            if(0 == dwellTimer)                          // heat on dwell time delay over?
            {
               cleanCycleFlags.heatOnActive = NO;        // yes, done with heat on
               nextState = HEAT_AND_CLEAN_ON;            // onto heat and clean on part of
                                                         // process...
            }
         }
         else
         {
            InitCleanStateMachine();                      // no... can't execute clean cycle...
         }
         break;

      case HEAT_AND_CLEAN_ON:                             // if state is heat and clean on...

         if(NO == cleanCycleFlags.heatAndCleanActive)     // first pass through heat and clean on?
         {
            dwellTimer = FIVE_SECONDS_10MS_TIME_VALUE;    // init heat and clean time delay
            cleanCycleFlags.heatAndCleanActive = YES;     // track that we're in heat and clean
                                                          // on state
         }
         if(YES == inputStatus.hdeSense)                  // is standing pilot present?
         {
            relayControlFlags.heatDemandRelay = ON;       // yes, turn on heat demand relay
            relayControlFlags.cleanRelay = ON;            // also turn on clean relay
            if(0 == dwellTimer)                           // heat on dwell time delay over?
            {
               cleanCycleFlags.heatAndCleanActive = NO;   // yes, done with heat and clean
               nextState = DWELL;                         // yes, onto dwell...
            }
         }
         else
         {
            InitCleanStateMachine();                      // no... can't execute clean cycle...
         }

         break;

      case DWELL:                                         // if state is dwell...

         if(NO == cleanCycleFlags.dwellActive)            // first pass through dwell?
         {
            dwellTimer = EIGHT_SECONDS_10MS_TIME_VALUE;   // init dwell time delay
            cleanCycleFlags.dwellActive = YES;            // track that we're in dwell state
         }
         if(YES == inputStatus.hdeSense)                  // is standing pilot present?
         {
            relayControlFlags.heatDemandRelay = OFF;      // yes, turn off heat demand
                                                          // and clean relay
            relayControlFlags.cleanRelay = OFF;
            if(0 == dwellTimer)                           // dwell time delay over?
            {
               cleanCycleFlags.dwellActive = NO;          // yes, done with dwell
               cleanCycleFlags.cleanActive = NO;          // clean cycle is no longer active
               cleanCycleFlags.cleanFinished = YES;       // inidicate completion of clean cycle
               nextState = INITIAL_BURN;                  // set default state of initial burn
            }
         }
         else
         {
            InitCleanStateMachine();                      // no... can't execute clean cycle...
         }

         break;

      default:

         InitCleanStateMachine();                         // if here, something broke... reset
                                                          // state machine...
         break;

   }
}

/**********************************************************************/
//User Main Defined
/**********************************************************************/
void Usermain(void)
{
    Init_hardware();                                    // configure MCU clock, timer
                                                        // interrupt, I/O port assignments,
                                                        // UART for host modbus communications.
    Init_system();                                      // initialize flag registers, I/O
                                                        // states, and timer variables
    user_uart0_Print_msg("WELCOME\r\n");
   // R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);
    while(1)
    {
        GetModbusAddress();

        if(MODBUS_DIRECT_WIRE_SEL == HIGH)
        {
            ModbusCheckRxBufferCount();
            // act on peripheral input data
            UpdateHostCommFlags();
            RunSystem();                                  // in essence, be a Pitco relay control

            // adjust peripheral outputs based on latest system status

            Leds();                                       // update LED on/off state based on
                                                          // latest LED control flag state.
            Relays();                                     // update relay output states based on
                                                          // latest relay control flag states
        }
        else
        {
            OneSecondTasks();

            Leds();

            Relays();
        }
    }
    R_BSP_PinAccessDisable();
}
/********************************END***********************************/
