/******************************************************************************************************************************************************
  Copyright 2013 Food Automation - Service Techniques (FAST.).  The computer program contained herein is the property of (FAST.) and may not be copied
  in whole or in part without prior written authorization from (FAST.).
********************************************************************************************************************************************************
********************************************************************************************************************************************************
File:   MODBUS.c

Creation Date:    03/13/13
Author:           A. Zimmerman

Description:
   This file contains all the internal variables and functions of the Modbus as used in pitco fryer

REVISION HISTORY:
********************************************************************************************************************************************************/
#include "Modbus.h"
#include "ModbusComm.h"
#include "ModbusApplication.h"
#include <string.h>

//Variables
//*****************************************************************************
const MODBUS_SIGNED_8BIT modbusDiscreteOutputsReadRequest[11]  = "0100000020";   //Modbus Read Coils
const MODBUS_SIGNED_8BIT modbusDiscreteInputsRead[11]          = "0200000020";   //Modbus Read Discrete Inputs
const MODBUS_SIGNED_8BIT modbusRegisterOutputsReadRequest[11]  = "0300000008";   //Modbus Read Holding Registers
const MODBUS_SIGNED_8BIT modbusRegisterInputsReadRequest[11]   = "0400000008";   //Modbus Read Input Register
const MODBUS_SIGNED_8BIT modbusDiscreteOutputsWriteRequest[13] = "0F0000002004";	//Modbus Write Multiple Coils
const MODBUS_SIGNED_8BIT modbusRegisterOutputsWriteRequest[13] = "100000000810";	//Modbus Write Multiple Registers

const MODBUS_SIGNED_8BIT modbusDiscreteInputsReadResponse[5] ="0204"; //Modbus Read Input Register Response
const MODBUS_SIGNED_8BIT modbusRegisterInputsReadResponse[5] ="0410";//Modbus Read Discrete Inputs Response
const MODBUS_SIGNED_8BIT modbusRegisterOutputsWriteResponse[11] = "1000000008";  //Modbus Write Multiple Registers Response
const MODBUS_SIGNED_8BIT modbusDiscreteOutputsWriteResponse[11] = "0F00000020";   //Modbus Write Multiple Coils Response
const MODBUS_SIGNED_8BIT crlf_str[3] = {0x0d, 0x0a, 0x00};

MODBUS_UNSIGNED_8BIT modbusActivity[2] = {0, 0};
MODBUS_UNSIGNED_8BIT modbusCurrentState = 0;
MODBUS_DATA *modbusDataPtr = 0;

//*****************************************************************************
void                 ModbusReadRequest(const MODBUS_SIGNED_8BIT * type, MODBUS_UNSIGNED_8BIT address);
void                 ModbusWriteRequest(MODBUS_SIGNED_8BIT type, MODBUS_UNSIGNED_8BIT address);
MODBUS_UNSIGNED_8BIT ModbusVerifyLRC(const MODBUS_SIGNED_8BIT * rcvdMessage);
void                 ModbusAppendLRC(MODBUS_SIGNED_8BIT * xmitMessage);
void                 ModbusAppendCRLF(MODBUS_SIGNED_8BIT * xmitMessage);
MODBUS_UNSIGNED_8BIT ModbusAsciiHexToUbyte(const MODBUS_SIGNED_8BIT* target);
MODBUS_SIGNED_8BIT * ModbusUbyteToAsciiHexStr(MODBUS_UNSIGNED_8BIT number);
MODBUS_UNSIGNED_8BIT ModbusParseMessage(const MODBUS_SIGNED_8BIT * rcvdMessage, MODBUS_UNSIGNED_8BIT slaveTarget);

/*****************************************************************************
Function Name:       ModbusInit

Description:         Initialize modbus software set up pointer to data supplied by Application.
                     Initialize modbus HW

Inputs:              Ptr to structure that has all discretes (booleans) and registers for input and out[ut
Outputs:             NONE

Author:              A. Zimmmerman 03/14/13
******************************************************************************/
void ModbusInit(MODBUS_DATA *data)
{
	modbusDataPtr = data;
	modbusCurrentState = 0;
	 
   ModbusInitializeHW();
}

/*****************************************************************************
Function Name:       ModbusAsciiHexToUbyte

Description:         Takes two bytes of ASCII located a target and converts to
                     to unsigned byte returns 0 if non-ASCII characters passed in.

Inputs:              pointer to ASCII BYTES
Outputs:             resulting HEX byte

Author:              A. Zimmmerman 03/14/13
******************************************************************************/
MODBUS_UNSIGNED_8BIT ModbusAsciiHexToUbyte(const MODBUS_SIGNED_8BIT* target) 
{
	MODBUS_UNSIGNED_8BIT result = 0;

	if (*target >= MODBUS_ASCII_CHAR_ZERO && *target <= MODBUS_ASCII_CHAR_NINE)
	{
		result += ( MODBUS_UNSIGNED_8BIT)((*target - MODBUS_ASCII_CHAR_ZERO) * 16);
	}
	else if (*target >= MODBUS_ASCII_CHAR_A && *target <= MODBUS_ASCII_CHAR_F)
	{
		result += ( MODBUS_UNSIGNED_8BIT)(((*target + 10) - MODBUS_ASCII_CHAR_A) * 16);
	}
	else
	{
		return 0;
	}

	if (*(target + 1) >= MODBUS_ASCII_CHAR_ZERO && *(target + 1) <= MODBUS_ASCII_CHAR_NINE)
	{
		result += ( MODBUS_UNSIGNED_8BIT)(*(target + 1) - MODBUS_ASCII_CHAR_ZERO);
	}
	else if (*(target + 1) >= MODBUS_ASCII_CHAR_A && *(target + 1) <= MODBUS_ASCII_CHAR_F)
	{
		result += ( MODBUS_UNSIGNED_8BIT)((*(target + 1) + 10) - MODBUS_ASCII_CHAR_A);
	}
	else
	{
		return 0;
	}

	return result;
}

/*****************************************************************************
Function Name:       ModbusUbyteToAsciiHexStr

Description:         Takes HEX Byte converts to an two character ASCII String.

Inputs:              resulting HEX byte
Outputs:             ASCII String

Author:              A. Zimmmerman 03/14/13
******************************************************************************/
MODBUS_SIGNED_8BIT * ModbusUbyteToAsciiHexStr(MODBUS_UNSIGNED_8BIT number)
{
	MODBUS_SIGNED_8BIT result;
	static char string[3];
   
   //lint -e534 ignoring return
   memset(string, 0, (MODBUS_UNSIGNED_32BIT)3);

	//MSB
	result = ((number >> 4) & 0x0F);

	if (result <= 9)
	{
		string[0] = result + MODBUS_ASCII_CHAR_ZERO;
	}
	else if ((result >= 10) && (result <= 15))
	{
		string[0] = (result - 10) + MODBUS_ASCII_CHAR_A;
	}
	else 
	{
		return 0;
	}

	//LSB
	result = (number & 0x0F);

	if (result <= 9)
	{
		string[1] = result + MODBUS_ASCII_CHAR_ZERO;
	}
	else if (result >= 10 && result <= 15) 
	{
		string[1] = (result - 10) + MODBUS_ASCII_CHAR_A;
	}
	else 
	{
		return 0;
	}


	return string;
}


/*****************************************************************************
Function Name:       ModbusVerifyLRC

Description:         This verifies the ASCII CHECKSUM received is good

Inputs:              Ptr to received Modbus Frame
Outputs:             MODBUS_TRUE or MODBUS_FALSE

Author:              A. Zimmmerman 03/14/13
******************************************************************************/
MODBUS_UNSIGNED_8BIT ModbusVerifyLRC(const MODBUS_SIGNED_8BIT * rcvdMessage)
{
	MODBUS_SIGNED_16BIT lrcCalc = 0;
	MODBUS_UNSIGNED_16BIT i, rcvdLength;
   MODBUS_UNSIGNED_8BIT lrcResult = MODBUS_FALSE;

	rcvdLength = (MODBUS_UNSIGNED_16BIT)strlen(rcvdMessage);

	if( rcvdLength < MODBUS_MIN_FRAME_SIZE ) 
	{
		; //absolute minimum, not even valid- START ':' (1), SLAVE "XX" (2), LRC "YY" (2), STOP 0x0a 0x0d (2)
	}
	else 
	{
		for(i = 1; i < rcvdLength - 4; i += 2)  //4 (LRC (2 bytes) + CR +LF) the 2 is because each 2 ASCII characters is on HEX Byte
		{
			lrcCalc += ModbusAsciiHexToUbyte(&rcvdMessage[i]);
		}

		lrcCalc *= -1;
		lrcCalc &= 0x00ff;

      //The LRC calculated must match the LRC received
		if(ModbusAsciiHexToUbyte(&rcvdMessage[rcvdLength - 4]) == (MODBUS_UNSIGNED_8BIT)lrcCalc)
		{
			lrcResult = MODBUS_TRUE;
		}
	}
   return lrcResult;

}

/*****************************************************************************
Function Name:       ModbusAppendLRC

Description:         This routine calculates the LRC for the frame to be transmitted and
                     appends the ASCII Characters to the message

Inputs:              Ptr to Modbus Frame to be transmitted
Outputs:             NONE

Author:              A. Zimmmerman 03/14/13
******************************************************************************/
void ModbusAppendLRC(MODBUS_SIGNED_8BIT * xmitMessage) 
{
	MODBUS_SIGNED_16BIT lrcCalc = 0;
	MODBUS_UNSIGNED_8BIT i;

	for(i = 1; i < strlen(xmitMessage); i += 2)
   {
		lrcCalc += ModbusAsciiHexToUbyte(&xmitMessage[i]);
   }

	lrcCalc *= -1;
	lrcCalc &= 0x00ff;

   //lint -e534 ignoring return
	strcat(xmitMessage, ModbusUbyteToAsciiHexStr((MODBUS_UNSIGNED_8BIT)lrcCalc));

	return;

}

/*****************************************************************************
Function Name:       ModbusAppendCRLF

Description:         This routine appends the ASCII CR and LF Characters to the message

Inputs:              Ptr to Modbus Frame to be transmitted
Outputs:             NONE

Author:              A. Zimmmerman 03/14/13
******************************************************************************/
void ModbusAppendCRLF(MODBUS_SIGNED_8BIT * xmitMessage)
{
   //lint -e534 ignoring return
	strcat(xmitMessage, crlf_str);
}

   MODBUS_SIGNED_8BIT modbusOutStr[MODBUS_BUFFER_LENGTH];
/*****************************************************************************
Function Name:       ModbusReadRequestResponse

Description:         This routine Builds and transmits requests 

Inputs:              Ptr to Modbus Command Str and address of Slave.
Outputs:             NONE

Author:              A. Zimmmerman 03/14/13
******************************************************************************/
void ModbusReadRequestResponse(MODBUS_SIGNED_8BIT type, MODBUS_UNSIGNED_8BIT address)
{
	MODBUS_UNSIGNED_8BIT j, booleanMerged = 0;
   MODBUS_UNSIGNED_16BIT registerWord;

   //lint -e534 ignoring return
   //lint -e534 ignoring return
	memset(modbusOutStr, 0, (MODBUS_UNSIGNED_32BIT)MODBUS_BUFFER_LENGTH); //clear the last frame out

	switch (type)
	{
   	case MODBUS_READ_DISCRETES:
         modbusOutStr[0] = MODBUS_START_DELIMITER;
         //lint -e534 ignoring return
      	strcat((MODBUS_SIGNED_8BIT *)modbusOutStr, (MODBUS_SIGNED_8BIT *)ModbusUbyteToAsciiHexStr(address)); //Put the address bytes in msg
         //lint -e534 ignoring return
   		strcat((MODBUS_SIGNED_8BIT *)modbusOutStr, (MODBUS_SIGNED_8BIT *)MODBUS_DIRRR); //Put type string in buffer for uart

         //shift in the bits and add each byte as ASCII to transmit buffer
   		for(j = 0; j < MODBUS_BOOLEANS; j++) 
   		{
            //clear byte before start of each byte
   			if( !(j % 8) ) 
   			{
   				booleanMerged = 0;
   			}
   			
            //shift in next bit
            booleanMerged |= (MODBUS_UNSIGNED_8BIT)((*(MODBUS_UNSIGNED_8BIT*)&modbusDataPtr->modbusDiscretes[MODBUS_TRANSMIT_DATA][j]) << (j % 8));
            
            //a full byte is ready so convert to ASCII and add to string
   			if( (j % 8) == 7 )
   			{
               //lint -e534 ignoring return
   				strcat((MODBUS_SIGNED_8BIT *)&modbusOutStr[MODBUS_START_OF_FRAME_DATA_BYTES + ((j / 8) * 2)], ModbusUbyteToAsciiHexStr( booleanMerged ));
   			}
   		}
   	break;

   	case MODBUS_READ_INPUT_REGISTER:
         modbusOutStr[0] = MODBUS_START_DELIMITER;
         //lint -e534 ignoring return
      	strcat((MODBUS_SIGNED_8BIT *)modbusOutStr, ModbusUbyteToAsciiHexStr(address)); 
         //lint -e534 ignoring return
   		strcat((MODBUS_SIGNED_8BIT *)modbusOutStr, (MODBUS_SIGNED_8BIT *)MODBUS_RIRRR); //Put type string in buffer for uart
   		for(j = 0; j < MODBUS_REGISTERS; j++)
   		{
            #ifdef MODBUS_PROCESSOR_LITTLE_ENDIAN
   			   //SWAP BIG ENDIAN HERE FOR OUTPUT OF REGISTERS
               registerWord = modbusDataPtr->modbusRegisters[MODBUS_TRANSMIT_DATA][j] >> 8;
               //lint -e534 ignoring return
   			   strcat((MODBUS_SIGNED_8BIT *)modbusOutStr, ModbusUbyteToAsciiHexStr( (MODBUS_UNSIGNED_8BIT)registerWord ));
               registerWord = modbusDataPtr->modbusRegisters[MODBUS_TRANSMIT_DATA][j] & 0x00ff;
               //lint -e534 ignoring return
   			   strcat((MODBUS_SIGNED_8BIT *)modbusOutStr, ModbusUbyteToAsciiHexStr( (MODBUS_UNSIGNED_8BIT)registerWord ));
            #else
               //lint -e534 ignoring return
   			   strcat((MODBUS_SIGNED_8BIT *)modbusOutStr, ModbusUbyteToAsciiHexStr( *(MODBUS_UNSIGNED_8BIT *)&modbusDataPtr->modbusRegisters[MODBUS_TRANSMIT_DATA][j]) );
               //lint -e534 ignoring return
   			   strcat((MODBUS_SIGNED_8BIT *)modbusOutStr, ModbusUbyteToAsciiHexStr( *((MODBUS_UNSIGNED_8BIT *)&modbusDataPtr->modbusRegisters[MODBUS_TRANSMIT_DATA][j]+1)) );
            #endif
   		}
      break;
      
   	default:
   		return;
	}


	ModbusAppendLRC((MODBUS_SIGNED_8BIT *)modbusOutStr);   //add LRC
	ModbusAppendCRLF((MODBUS_SIGNED_8BIT *)modbusOutStr);  //add CRLF
	ModbusPutStringIntoOutputBuffer((const char *)modbusOutStr);
}

/*****************************************************************************
Function Name:       ModbusWriteRequest

Description:         This routine builds and transmits the Write Requests for both Discretes and Registers

Inputs:              type of write to perform and address of Slave.
Outputs:             NONE

Author:              A. Zimmmerman 03/14/13
******************************************************************************/
void ModbusWriteRequestResponse(const MODBUS_SIGNED_8BIT * type, MODBUS_UNSIGNED_8BIT address) 
{
   //lint -e534 ignoring return
	memset(modbusOutStr, 0, (MODBUS_UNSIGNED_32BIT)MODBUS_BUFFER_LENGTH); //clear the last frame out
   modbusOutStr[0] = MODBUS_START_DELIMITER;
   //lint -e534 ignoring return
	strcat((MODBUS_SIGNED_8BIT *)modbusOutStr, ModbusUbyteToAsciiHexStr(address)); //Put the address bytes in msg
   //lint -e534 ignoring return
	strcat((MODBUS_SIGNED_8BIT *)modbusOutStr, type); //Put type (command) string in buffer for uart
	ModbusAppendLRC((MODBUS_SIGNED_8BIT *)modbusOutStr);   //Checksum the frame and append it.
	ModbusAppendCRLF((MODBUS_SIGNED_8BIT *)modbusOutStr);  //add carriage return line feed
	ModbusPutStringIntoOutputBuffer((const char *)modbusOutStr);


}

/*****************************************************************************
Function Name:       ModbusParseMessage

Description:         This routine builds and transmits the Write Requests for both Discretes and Registers

Inputs:              pointer to received message and slave address.
Outputs:             Status frame received good or reason bad

Author:              A. Zimmmerman 03/14/13
******************************************************************************/
MODBUS_UNSIGNED_8BIT ModbusParseMessage(const MODBUS_SIGNED_8BIT * rcvdMessage, MODBUS_UNSIGNED_8BIT slaveTarget)
{
	MODBUS_UNSIGNED_8BIT    slaveAddress = 1;
   MODBUS_UNSIGNED_8BIT    booleanParser, rxTx, j, k;
   MODBUS_UNSIGNED_16BIT   length;
   MODBUS_UNSIGNED_8BIT    result;
   MODBUS_UNSIGNED_8BIT    inOutType;
   
   result = 0;
   length = (MODBUS_UNSIGNED_16BIT)strlen(rcvdMessage);
   rxTx = MODBUS_TRANSMIT_DATA;

	if( rcvdMessage[0] != MODBUS_START_DELIMITER )
	{
		result =  MODBUS_BAD_LRC;
	}
	else if( !ModbusVerifyLRC(rcvdMessage) ) 
	{
		result =  MODBUS_BAD_LRC;
	}
	else 
	{
		slaveAddress = ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_SLAVE_ADDR_LOCATION]);

		if(slaveAddress != slaveTarget ) 
      {
			result = MODBUS_SLAVE_MISMATCH;
		}

	}
   
   if(0 == result)
   {
      inOutType = ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_FUNCTION_LOCATION]);
   	switch( inOutType ) 
      {

  		   case MODBUS_WRITE_COILS:
            if ( MODBUS_WRITE_COILS == inOutType)
            {
   			   rxTx += MODBUS_RECEIVE_DATA;
            }               
   			rxTx += MODBUS_TRANSMIT_DATA;
 
            if(length != MODBUS_WRITE_COILS_FRAME_LENGTH)
            {
   				result = MODBUS_NONCOMPATIBLE;
            }
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_WRITE_REQUEST_ADDR_HI_LOCATION]) != 0 ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_WRITE_REQUEST_ADDR_LO_LOCATION]) != 0 ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_WRITE_REQUEST_QTY_HI_LOCATION]) != 0 ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_WRITE_REQUEST_QTY_LO_LOCATION]) != MODBUS_BOOLEANS ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else if(( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_DISCRETE_COUNT_LOCATION]) != MODBUS_DISCRETE_BYTE_COUNT ) )
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else 
            {
   				for(j = MODBUS_BOOLEAN_DATA_START_LOCATION; j < (((((MODBUS_BOOLEANS - 1) / 8) + 1) * 2) + MODBUS_BOOLEAN_DATA_START_LOCATION); j += 2) 
               {
   					booleanParser = ModbusAsciiHexToUbyte(&rcvdMessage[j]);

   					for(k = 0; k < 8; k++)
                  {
   						*(MODBUS_UNSIGNED_8BIT*)&modbusDataPtr->modbusDiscretes[rxTx][((j - MODBUS_BOOLEAN_DATA_START_LOCATION) * 4) + k] 
                     = (MODBUS_UNSIGNED_8BIT)((booleanParser >> k) & 0x01);
                  }
   				}
   			   result = MODBUS_RECEIVE_SUCCESS + MODBUS_DISCRETE_WRITE + rxTx;
   			}

            break;


   		case MODBUS_WRITE_MULTIPLE_REGISTERS:
            if ( MODBUS_WRITE_MULTIPLE_REGISTERS == inOutType)
            {
   			   rxTx += MODBUS_RECEIVE_DATA;
            }               
   			rxTx += MODBUS_TRANSMIT_DATA;

            if(length != MODBUS_WRITE_REGISTERS_FRAME_LENGTH)
            {
   				result = MODBUS_NONCOMPATIBLE;
            }
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_WRITE_REQUEST_ADDR_HI_LOCATION]) != 0 ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_WRITE_REQUEST_ADDR_LO_LOCATION]) != 0 ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_WRITE_REQUEST_QTY_HI_LOCATION]) != 0 ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_WRITE_REQUEST_QTY_LO_LOCATION]) != MODBUS_REGISTERS ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
    			else if(ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_REGISTER_COUNT_LOCATION]) != MODBUS_REGISTER_BYTE_COUNT )
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else 
            {
   				for(j = MODBUS_REGISTER_DATA_START_LOCATION, k = 0; j < ((MODBUS_REGISTERS * 4) + MODBUS_REGISTER_DATA_START_LOCATION); j += 4, k++)
               {
                  #ifdef MODBUS_PROCESSOR_LITTLE_ENDIAN
                  //SWAP BIG ENDIAN HERE FOR INPUT OF REGISTERS
      					modbusDataPtr->modbusRegisters[rxTx][k] = (MODBUS_UNSIGNED_16BIT)ModbusAsciiHexToUbyte(&rcvdMessage[j]) << 8;
      					modbusDataPtr->modbusRegisters[rxTx][k] += ModbusAsciiHexToUbyte(&rcvdMessage[j+2]);
                  #else
      					*(MODBUS_UNSIGNED_8BIT *)&modbusDataPtr->modbusRegisters[rxTx][k] = ModbusAsciiHexToUbyte(&rcvdMessage[j]);
      					*((MODBUS_UNSIGNED_8BIT *)&modbusDataPtr->modbusRegisters[rxTx][k]+1) = ModbusAsciiHexToUbyte(&rcvdMessage[j+2]);
                  #endif
               }
   		   	result = MODBUS_RECEIVE_SUCCESS + MODBUS_REGISTER_WRITE + rxTx;
   			}

            break;

   		case MODBUS_READ_DISCRETES:
   		case MODBUS_READ_COILS:
            if(length != MODBUS_DISCRETE_READ_FRAME_LENGTH)
            {
               result = MODBUS_NONCOMPATIBLE;
            }
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_READ_REQUEST_ADDR_HI_LOCATION]) != 0 ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_READ_REQUEST_ADDR_LO_LOCATION]) != 0 ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_READ_REQUEST_QTY_HI_LOCATION]) != 0 ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_READ_REQUEST_QTY_LO_LOCATION]) != MODBUS_BOOLEANS ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else 
            {
   				result = MODBUS_RECEIVE_SUCCESS + MODBUS_DISCRETE_READ;
   			}
            break;

   	   case MODBUS_READ_INPUT_REGISTER:
         case MODBUS_READ_HOLDING_REGISTERS:
            if( length != MODBUS_REGISTER_READ_FRAME_LENGTH)
            {
               result = MODBUS_NONCOMPATIBLE;
            }
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_READ_REQUEST_ADDR_HI_LOCATION]) != 0 ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_READ_REQUEST_ADDR_LO_LOCATION]) != 0 ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_READ_REQUEST_QTY_HI_LOCATION]) != 0 ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else if( ModbusAsciiHexToUbyte(&rcvdMessage[MODBUS_READ_REQUEST_QTY_LO_LOCATION]) != MODBUS_REGISTERS ) 
            {
   				result = MODBUS_NONCOMPATIBLE;
   			}
   			else 
            {
   				result = MODBUS_RECEIVE_SUCCESS + MODBUS_REGISTER_READ;
   			}
            break;

   		default:
   			result= MODBUS_NONCOMPATIBLE;
            break;

   	}
   }
   
   modbusCommData.receivedFlag = MODBUS_FALSE;
   return result;

}

/*****************************************************************************
Function Name:       ModbusUpdateService

Description:         This routine needs to be called every 100 msec. Processes messages
                     from the MASTER and maintains communication timeout.

Inputs:              Slave address (presently only one slave also Address of data always starts at zero).
Outputs:             NONE

Author:              A. Zimmmerman 03/14/13
******************************************************************************/
void ModbusUpdateService(MODBUS_UNSIGNED_8BIT slaveAddress)
{
	static MODBUS_UNSIGNED_8BIT retValue;

	if(MODBUS_TRUE == modbusCommData.receivedFlag) 
   {
      retValue = ModbusParseMessage(modbusReceivedData, slaveAddress);
      switch( retValue )
      {
         case MODBUS_DISCRETE_OUTPUT_READ_SUCCESS:
			   ModbusReadRequestResponse(MODBUS_READ_DISCRETES, slaveAddress);
            modbusActivity[0] = 0;
            break;
         case MODBUS_REGISTER_OUTPUT_READ_SUCCESS:
			   ModbusReadRequestResponse(MODBUS_READ_INPUT_REGISTER, slaveAddress);
            modbusActivity[0] = 0;
            break;

         case MODBUS_DISCRETE_OUTPUT_WRITE_SUCCESS:
			   ModbusWriteRequestResponse((const char *)MODBUS_DOWRR, slaveAddress);
            modbusActivity[1] = 1;
            break;
            
         case MODBUS_REGISTER_OUTPUT_WRITE_SUCCESS:
			   ModbusWriteRequestResponse((const char *)MODBUS_ROWRR, slaveAddress);
            modbusActivity[1] = 1;
            break;

         default:
            break;
      }

   }
   
  
   if(++modbusActivity[0] > MODBUS_ACTIVITY_TIMEOUT_IN_100MSECS )
   {
       modbusActivity[0] = MODBUS_ACTIVITY_TIMEOUT_IN_100MSECS;
   }
   
   if(++modbusActivity[1] > MODBUS_ACTIVITY_TIMEOUT_IN_100MSECS )
   {
       modbusActivity[1] = MODBUS_ACTIVITY_TIMEOUT_IN_100MSECS;
   }

}

/*****************************************************************************
Function Name:       ModbusDataValid

Description:         This function looks at activity timers (presently 5 seconds) and if both have activity
                     returns MODBUS_TRUE. If no activity data should be disregarded.

Inputs:              NONE
Outputs:             MODBUS_TRUE or MODBUS_FALSE

Author:              A. Zimmmerman 03/14/13
******************************************************************************/
MODBUS_UNSIGNED_8BIT ModbusDataValid(void) 
{
	if( ( modbusActivity[0] < MODBUS_ACTIVITY_TIMEOUT_IN_100MSECS ) && ( modbusActivity[1] < MODBUS_ACTIVITY_TIMEOUT_IN_100MSECS ) )
   {
      return MODBUS_TRUE;
   }
	else
   {
      return MODBUS_FALSE;
   }
}








