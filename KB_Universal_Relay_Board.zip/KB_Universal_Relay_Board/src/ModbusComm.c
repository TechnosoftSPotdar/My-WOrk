/*---------------------------------------------------------------------------
  Copyright 2015-2020 Food Automation - Service Techniques (FAST.).  The
  computer program contained herein is the property of (FAST.) and may
  not be copied in whole or in part without prior written authorization
  from (FAST.).
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

File         : ModbusComm.c
Creation Date: 01/07/2015
Author       : A. Zimmerman

Description: 
   This file contains the modbus communitcation functions for handling physical layer
   of MODBUS COMM PORT NON-DMA.

REVISION HISTORY:
----------------------------------------------------------------------------*/
#include <string.h>
#include "Modbus.h"
#include "ModbusComm.h"
#include "ModbusApplication.h"
#include "ModbusGeneralDefs.h"
#include "UserMain.h"
volatile MODBUS_STRUCT modbus;
MODBUS_SIGNED_8BIT               modbusReceivedData[MODBUS_BUFFER_LENGTH];
//volatile MODBUS_DMA_CONTROL_DATA modbusDMADataRx;
volatile MODBUS_COMM_DATA        modbusCommData;

void ModbusInitializeHW( void )
{
     /******************************************************************************************/
   /*           C O N F I G U R E  U A R T 1  F O R  M O D B U S  I N T E R F A C E          */
   /******************************************************************************************/
   /*  This is the main UART1 (TxD1/RxD1) on the Pitco relay board...                        */
   /******************************************************************************************/

   
   //lint -e{534} Ignoring return value of function
   memset( (void*)&modbus, 0, sizeof(MODBUS_STRUCT) );
}



/***************************************************************
   Function Name: Modbus_UART1_Receive

   Description:  Receive Interrupt Routine

   Inputs:        None

   Outputs:       None

   Author:        A. Zimmerman  1/7/2015

   Modified:
****************************************************************/
void Modbus_UART1_Receive(MODBUS_UNSIGNED_8BIT Received_Char)
{
    if(Received_Char & 0xF000)
    {

    }
    else
    {
        modbus.rxBuffer[modbus.rxBufferHeadIdx] = (MODBUS_UNSIGNED_8BIT)(Received_Char & 0xFF);
                  
       if( ++modbus.rxBufferHeadIdx >= MODBUS_RX_BUFFER_SIZE )
       {
            modbus.rxBufferHeadIdx = 0;
       }
    }
}

/***************************************************************
   Function Name: Modbus_UART1_Transmit

   Description:  MODBUS TRANSMIT interrupt handler

   Inputs:        None

   Outputs:       None

   Author:        A. Zimmerman  

   Modified:
****************************************************************/

MODBUS_SIGNED_8BIT Modbus_UART1_Transmit(void)
{
    MODBUS_SIGNED_8BIT MODBUS_TX_BUFFER = 0;
   if( modbus.txBufferHeadIdx != modbus.txBufferTailIdx )          //there is data to send
   {
      // tx enabled - data to send
      ModbusEnableRTS();
      
     MODBUS_TX_BUFFER = (MODBUS_SIGNED_8BIT)(modbus.txBuffer[modbus.txBufferTailIdx] & 0xff);;
      if( ++modbus.txBufferTailIdx >= MODBUS_TX_BUFFER_SIZE )
      {
         modbus.txBufferTailIdx = 0;
      }
      
   }
   else
   {
      // tx disable - done sending data
      ModbusDisableRTS();
   }
   return MODBUS_TX_BUFFER;
}

/***************************************************************
   Function Name: ModbusRxMachine

   Description:  process byte received to find modbus frame

   Inputs:        byte received

   Outputs:       None

   Author:        A. Zimmerman  

   Modified:
****************************************************************/
void ModbusRxMachine( MODBUS_SIGNED_8BIT receivedByte )
{

	//Whenever the start delimiter is seen then clear and
	//restart the search for a valid MODBUS frame
	if( MODBUS_START_DELIMITER == receivedByte)
	{
		//reset the index
		modbusCommData.receivedIndex = 0; //not storing the start delimiter
		//store this character in the receive buffer
		modbusReceivedData[modbusCommData.receivedIndex++] = receivedByte;
	}
	//has the receive buffer been overrun??
	else if(modbusCommData.receivedIndex >= MODBUS_BUFFER_LENGTH) 
	{
      //lint -e534 ignoring return
		memset(modbusReceivedData,0, (MODBUS_SIGNED_32BIT)MODBUS_BUFFER_LENGTH);
		modbusCommData.receivedIndex = 0;
	}
	else
	{
   	//store this character in the receive buffer
		modbusReceivedData[modbusCommData.receivedIndex++] = receivedByte;
		//is this a packet termination character??
		if((MODBUS_ASCII_CHAR_LF == receivedByte) && (MODBUS_ASCII_CHAR_CR == modbusReceivedData[modbusCommData.receivedIndex-2]))
		{
			//Compare frame received with last frame sent out if it is reset index
			modbusReceivedData[modbusCommData.receivedIndex] = MODBUS_NULL; //ensure null terminated
         modbusCommData.receivedFlag = MODBUS_TRUE;//notify that we have a packet ready
		}
	}
   
}

/***************************************************************
 Function Name:	RS485CheckRxBufferCount

 Description:		Checks head tail of receive and calls the receive machine
                  with each byte accordingly

 Inputs:				void

 Outputs:			void

 Author:				A. Zimmerman

 Modified:
****************************************************************/
void ModbusCheckRxBufferCount( void )
{
   MODBUS_UNSIGNED_16BIT headIdx = modbus.rxBufferHeadIdx;
   
   while( modbus.rxBufferTailIdx != headIdx )
   {
      ModbusRxMachine((MODBUS_SIGNED_8BIT) modbus.rxBuffer[modbus.rxBufferTailIdx] );
      
      if (++modbus.rxBufferTailIdx >= MODBUS_RX_BUFFER_SIZE)
      {
         modbus.rxBufferTailIdx = 0;
      }
   }
   
}

/***************************************************************
 Function Name:	ModbusDisableRTS

 Description:		Sets Driver to RECEIVE DATA

 Inputs:				void

 Outputs:			void

 Author:				A. Zimmerman

 Modified:
****************************************************************/
void ModbusDisableRTS( void )
{
    RS485_INT_PIN(OFF);
}

/***************************************************************
 Function Name:	ModbusEnableRTS

 Description:		Enables to TRANSMIT DATA

 Inputs:				void

 Outputs:			void

 Author:				A. Zimmerman

 Modified:
****************************************************************/
void ModbusEnableRTS( void )
{
    RS485_INT_PIN(ON);
}

/***************************************************************
   Function Name: ModbusTxPutByteIntoOutputBuffer

   Description:   used to output bytes to uart if nothing in uart
                  kick start uart by sending first byte

   Inputs:        Byte to transmit

   Outputs:       None

   Author:        A. Zimmerman  

   Modified:
****************************************************************/
void ModbusTxPutByteIntoOutputBuffer( MODBUS_UNSIGNED_8BIT data )
{
   MODBUS_UNSIGNED_16BIT previousHeadIdx = modbus.txBufferHeadIdx;
   
   modbus.txBuffer[modbus.txBufferHeadIdx] = data;  //place data in output buffer
   if(++modbus.txBufferHeadIdx >= MODBUS_TX_BUFFER_SIZE )               //advance head ptr
   {
      modbus.txBufferHeadIdx = 0;                                     //wrap to zero
   }
   
   if((previousHeadIdx == modbus.txBufferTailIdx) )
   {
      // tx enabled - data to send
      ModbusEnableRTS();
      //MODBUS_SIGNED_8BIT MODBUS_TX_BUFFER = (MODBUS_SIGNED_8BIT)(modbus.txBuffer[modbus.txBufferTailIdx] & 0xff);
      if( ++modbus.txBufferTailIdx >= MODBUS_TX_BUFFER_SIZE )
      {
         modbus.txBufferTailIdx = 0;
      }
   }
}

/***************************************************************
   Function Name: ModbusTxPutStringIntoOutputBuffer

   Description:  Used to output a null-terminated string to
                 the output buffer.

   Inputs:        None

   Outputs:       None

   Author:        A. Zimmerman  

   Modified:
****************************************************************/
void ModbusTxPutStringIntoOutputBuffer( const MODBUS_SIGNED_8BIT* str )
{
   MODBUS_SIGNED_16BIT i = 0;

   while( str[i] != 0 )
   {
      ModbusTxPutByteIntoOutputBuffer( (MODBUS_UNSIGNED_8BIT)str[i++] );
   }
}
