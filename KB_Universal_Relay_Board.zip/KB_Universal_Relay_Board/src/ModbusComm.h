/*---------------------------------------------------------------------------
Copyright 2014-2050 Food Automation - Service Techniques (FAST.). The 
computer program contained herein is the property of (FAST.) and may
not be copied in whole or in part without prior written authorization
from (FAST.).
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
Filename:         RS-485.h   
Creation Date:    1/16/2014
Author:           GLU

Description:      This file contains the RS485 protocol processing routines
                  of the master side of the master/slave network.

REVISION HISTORY:

*****************************************************************************/
#ifndef __MODBUS_H__
#define __MODBUS_H__

#include "Modbus.h"
//*****************************************************************************
#define MODBUS_VERSION_HEADER             "W-RS485 1.0\n\r"

//*****************************************************************************
#define MODBUS_READ_REQUEST               0
#define MODBUS_WRITE_REQUEST              1

//*****************************************************************************
#define MODBUS_TX_BUFFER_SIZE             256
#define MODBUS_RX_BUFFER_SIZE             256

//********************************************
#define MODBUS_NUM_DATA_BUFFER            2
#define MODBUS_MAX_FRAME_SIZE			 513							//(1 Start Delimiter 2 Address Char + 2 function chars + (2*252) Data + 2 LRC + 2 CRLF)
#define MODBUS_MIN_FRAME_SIZE			  7							//Does not include ':"
#define MODBUS_BUFFER_LENGTH			  MODBUS_MAX_FRAME_SIZE+1	//ADD NULL Termination
#define MODBUS_START_OF_FRAME_DATA_BYTES  5

// UART mode, 8 data bits, use internal clock, one stop bit, no parity
#define MODBUS_SETUP_MODE_REGISTER        { smd0_u1mr = 1; smd1_u1mr = 0; smd2_u1mr = 1; ckdir_u1mr = 0; stps_u1mr = 0; prye_u1mr = 0; };                   

// sets TxD1 and RxD1 pins for TxD and RxD mode of operation...
#define MODBUS_PIN_SELECTION              u1pinsel = 1;

// BRG count source select bits, set to f1 (i.e. 16MHZ), TxD1 is a cmos output, transmit data is output at falling edge of transfer clock,
// receive data is input at rising edge and transfer format select bit 0 : LSB first
#define MODBUS_SETUP_CONTROL_REG_0       {   clk0_u1c0 = 0; clk1_u1c0 = 0; nch_u1c0 = 0; ckpol_u1c0 = 0; uform_u1c0 = 0; };
#define MODBUS_CONTROL_REG_1             u1c1 
                                 
#define MODBUS_DISABLE_CONTINUOUS_RECEIVE_MODE  u1rrm_u1c1 = 0;                     // disable continuous receive mode


typedef struct{
   MODBUS_UNSIGNED_8BIT             myAddress;

   MODBUS_UNSIGNED_8BIT             txBuffer[MODBUS_TX_BUFFER_SIZE];
   MODBUS_UNSIGNED_16BIT            txBufferHeadIdx;
   MODBUS_UNSIGNED_16BIT            txBufferTailIdx;

   MODBUS_UNSIGNED_8BIT             rxBuffer[MODBUS_RX_BUFFER_SIZE];
   MODBUS_UNSIGNED_16BIT            rxBufferHeadIdx;
   MODBUS_UNSIGNED_16BIT            rxBufferTailIdx;

}MODBUS_STRUCT;

//Data belonging to MODBUS MAC Layer
typedef struct {
   volatile MODBUS_UNSIGNED_8BIT transmitFlag;
   volatile MODBUS_UNSIGNED_8BIT transmitCompleteFlag;
   volatile MODBUS_UNSIGNED_8BIT receivedFlag;
   volatile MODBUS_UNSIGNED_16BIT receivedIndex;
}MODBUS_COMM_DATA;


//*****************************************************************************
extern volatile MODBUS_COMM_DATA modbusCommData;
extern volatile MODBUS_STRUCT modbus;
extern MODBUS_SIGNED_8BIT modbusReceivedData[MODBUS_BUFFER_LENGTH];
extern volatile MODBUS_COMM_DATA modbusCommData;
//*****************************************************************************
//in Modbus.c
void ModbusInitializeHW(void);
void ModbusDisableRTS( void );
void ModbusEnableRTS( void );

//in ModbusRx.c
void Modbus_UART1_Receive(MODBUS_UNSIGNED_8BIT Received_Char);
void ModbusRxMachine( MODBUS_SIGNED_8BIT receivedByte );
void ModbusCheckRxBufferCount(void);
void ModbusReceiveMachine( MODBUS_UNSIGNED_8BIT data );
void ModbusRxProcessIncomingMessages(void);

//in ModbusTx.c
MODBUS_SIGNED_8BIT Modbus_UART1_Transmit(void);
void ModbusTxPutByteIntoOutputBuffer(MODBUS_UNSIGNED_8BIT data);
void ModbusPutStringIntoOutputBuffer(const char *str);
void ModbusTxPutStringIntoOutputBuffer( const MODBUS_SIGNED_8BIT* str );

#endif
