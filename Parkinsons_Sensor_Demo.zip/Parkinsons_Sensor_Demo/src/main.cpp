#include <Arduino.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <RTClib.h>

File dataFile;
Adafruit_MPU6050 mpu;

#define MY_MPU6050_DEVICE_ID 0x69
bool toggle = HIGH;

int Interrupt_pin = 2; //define interrupt pin to 2
bool Button_State = LOW; // To make sure variables shared between an ISR 
RTC_DS3231 rtc;


unsigned long debounceDelay = 100;  


String FileName = { };
String TempFileName = { };
String TempDate = " ";


char readString[50] = { };   
int buffercount = 0;
bool serial_flag = false;

void Button_Input() 
{
  unsigned long lastDebounceTime = 0;  

  if (!(digitalRead(Interrupt_pin))) 
    lastDebounceTime = millis();

  while((millis() - lastDebounceTime) < debounceDelay);

  if (!(digitalRead(Interrupt_pin))) 
    Button_State = HIGH;
}

void setup(void) {
  Serial.begin(9600);
  //while (!Serial);
  
  pinMode(LED_BUILTIN,OUTPUT);

   if (!rtc.begin()) {
    Serial.println("Couldn't find RTC");
  }

  if (rtc.lostPower()) {
    Serial.println("Adjusting RTC please wait......");
    rtc.adjust(DateTime(2022, 9, 1, 10, 0, 0));
    // January 21, 2014 at 3am you would call:
    // rtc.adjust(DateTime(2014, 1, 21, 3, 0, 0));
  }

  attachInterrupt(digitalPinToInterrupt(Interrupt_pin), Button_Input, FALLING);

  Serial.println("Adafruit MPU6050 test!");
  
  if (!mpu.begin(MY_MPU6050_DEVICE_ID)) {
    Serial.println("Failed to find MPU6050 chip");
    while (1);
  }
  Serial.println("MPU6050 Found!");

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  Serial.print("Accelerometer range set to: ");
  switch (mpu.getAccelerometerRange()) {
  case MPU6050_RANGE_2_G:
    Serial.println("+-2G");
    break;
  case MPU6050_RANGE_4_G:
    Serial.println("+-4G");
    break;
  case MPU6050_RANGE_8_G:
    Serial.println("+-8G");
    break;
  case MPU6050_RANGE_16_G:
    Serial.println("+-16G");
    break;
  }
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  Serial.print("Gyro range set to: ");
  switch (mpu.getGyroRange()) {
  case MPU6050_RANGE_250_DEG:
    Serial.println("+- 250 deg/s");
    break;
  case MPU6050_RANGE_500_DEG:
    Serial.println("+- 500 deg/s");
    break;
  case MPU6050_RANGE_1000_DEG:
    Serial.println("+- 1000 deg/s");
    break;
  case MPU6050_RANGE_2000_DEG:
    Serial.println("+- 2000 deg/s");
    break;
  }

  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  Serial.print("Filter bandwidth set to: ");
  switch (mpu.getFilterBandwidth()) {
  case MPU6050_BAND_260_HZ:
    Serial.println("260 Hz");
    break;
  case MPU6050_BAND_184_HZ:
    Serial.println("184 Hz");
    break;
  case MPU6050_BAND_94_HZ:
    Serial.println("94 Hz");
    break;
  case MPU6050_BAND_44_HZ:
    Serial.println("44 Hz");
    break;
  case MPU6050_BAND_21_HZ:
    Serial.println("21 Hz");
    break;
  case MPU6050_BAND_10_HZ:
    Serial.println("10 Hz");
    break;
  case MPU6050_BAND_5_HZ:
    Serial.println("5 Hz");
    break;
  }

  Serial.println("");

  Serial.println("Initializing SD card...");
  if (!SD.begin(SS)) {
    Serial.println("Card failed, or not present");
    return;
  }
  Serial.println("card initialized.");
  Serial.println("");

  DateTime now = rtc.now();
  TempFileName = String(now.day()) + String(now.month()) + String(now.year()) + ".csv";
  TempDate = String(now.day());
  FileName = TempFileName;

   File data_String = SD.open(FileName.c_str(),FILE_WRITE);
   data_String.println("TimeStamp,Acceleration X(m/s^2),Acceleration Y(m/s^2),Acceleration Z(m/s^2),Rotation X(rad/s),Rotation Y(rad/s),Rotation Z(rad/s),Temperature(degC),Button Event");
   data_String.close();
  Button_State = LOW;
}
void loop() 
{
  if(toggle)
  {
    digitalWrite(LED_BUILTIN,HIGH);
    toggle = LOW;
  }
  else
  {
    digitalWrite(LED_BUILTIN,LOW);
    toggle = HIGH;
  }

  /*Serial RTC adjust*/
  if (Serial.available() > 0)
  {                               
      char c = Serial.read();
      if(c == '\r' || c == '\n')
      {buffercount = 0;serial_flag = true;}
      else
      {readString[buffercount++]= c;} 
      
   }
   if(serial_flag == true)
   {
    char buffer[5];
    buffer[0] = readString[0];
    buffer[1] = readString[1];
    buffer[2] = '\0';
    int mydate = atoi(buffer);
    buffer[0] = readString[2];
    buffer[1] = readString[3];
    buffer[2] = '\0';
    int mymonth = atoi(buffer);
    buffer[0] = readString[4];
    buffer[1] = readString[5];
    buffer[2] = readString[6];
    buffer[3] = readString[7];
    buffer[4] = '\0';
    int myyear = atoi(buffer);
    buffer[0] = readString[8];
    buffer[1] = readString[9];
    buffer[2] = '\0';
    int myhour = atoi(buffer);
    buffer[0] = readString[10];
    buffer[1] = readString[11];
    buffer[2] = '\0';
    int mymin = atoi(buffer);
    buffer[0] = readString[12];
    buffer[1] = readString[13];
    buffer[2] = '\0';
    int mysec = atoi(buffer);

    Serial.println("Adjusting RTC please wait......");
    rtc.adjust(DateTime(myyear, mymonth, mydate, myhour, mymin, mysec));
   }
  /*Serial RTC adjust*/

  /* Get new sensor events with the readings */
  String dataString = "";
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);
  DateTime now = rtc.now();
  /* Get new sensor events with the readings */

  /*File Name creation depending on Date*/
  if(TempDate != String(now.day()))
  {
    TempFileName = String(now.day()) + String(now.month()) + String(now.year()) + ".csv";
    TempDate = String(now.day());
    FileName = TempFileName;
  } 
  /*File Name creation depending on Date*/

  /* Date and Time Referance */  
  dataString += String(now.day());
  dataString += "/";
  dataString += String(now.month());
  dataString += "/";
  dataString += String(now.year());
  dataString += " ";
  dataString += String(now.hour());
  dataString += ":";
  dataString += String(now.minute());
  dataString += ":";
  dataString += String(now.second());
  dataString += ","; 
  /* Date and Time Referance */
  
  /* Print out the values */
  dataString += String(a.acceleration.x);
  dataString += ","; 
  dataString += String(a.acceleration.y);
  dataString += ",";
  dataString += String(a.acceleration.z);
  dataString += ",";
  dataString += String(g.gyro.x);
  dataString += ",";
  dataString += String(g.gyro.y);
  dataString += ",";
  dataString += String(g.gyro.z);
  dataString += ",";
  dataString += String(temp.temperature);
  dataString += ",";
  /* Print out the values */
  
  if(Button_State)
  {
    Button_State = LOW;
    dataString += "T"; //Button Event Occurred
  }
  else
  {
    dataString += "F";//Button Event None
  }
  /* Print out the values */
  Serial.println(dataString); //Debug printing
  /* Print out the values */

  /* Stoaring values in SD Card*/
  File dataFile = SD.open(FileName,FILE_WRITE);
   
  if (dataFile) 
    {
      
      dataFile.println(dataString);
      dataFile.close();
    }
    else 
    {
      Serial.println("error opening datalog file");
    }
  /* Stoaring values in SD Card*/
  
}
